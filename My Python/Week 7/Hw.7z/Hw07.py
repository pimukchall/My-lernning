c = int(input("Input C : "))

f = (9/5*c)+32
k = c + 273.15

print("C :",c,"\n","F :",f,"\n","K :",k)
