st = input("Input : ")
li = st.split()
print(li[0]+li[1]+li[2]+((li[0]+li[1])*int(li[2])))