import math
a = int(input("Input Number :"))
a = a**(1/3)
if( a%1 == 0) : print(a)
else : print("Not Found")