def factorial(n) :
    if n == 1 :
        return n
    else:
        return n * factorial(n - 1)

fac = int(input("Input Number : "))
print("Factorial",fac,"=",factorial(fac))